package c.comp3074project.applocation;

// Global variable file, just to test/set values for the map.  In the actual program instead of using
// global variables MapsActivity will call data from the selected entry in the database.

public class Global {
    public static String location;
    public static String latitude;
    public static String longitude;
}